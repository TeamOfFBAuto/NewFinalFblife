//
//  NewMineCustomCell.h
//  FbLife
//
//  Created by soulnear on 13-12-13.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewMineCustomCell : UITableViewCell

@end
