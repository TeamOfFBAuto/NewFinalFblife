//
//  wbCell.h
//  FbLife
//
//  Created by 史忠坤 on 13-2-28.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
@interface wbCell : UITableViewCell
@property(nonatomic,strong)AsyncImageView *_imagetouxiang;


@end
