//
//  SzkSegMent.h
//  FbLife
//
//  Created by 史忠坤 on 13-6-18.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SzkSegMent : UIView{
    UIButton *LeftButton;
    UIButton *RigthButton;
    
}

@end
