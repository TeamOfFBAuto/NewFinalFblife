//
//  FeedbackTableViewCell.h
//  UMeng Analysis
//
//  Created by liuyu on 9/18/12.
//  Copyright (c) 2012 Realcent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMFeedbackTableViewCellLeft : UITableViewCell {

    UIImageView *messageBackgroundView;
}

@property(nonatomic, retain) UILabel *timestampLabel;

@end
