//
//  summarycellview.h
//  FbLife
//
//  Created by 史忠坤 on 13-9-25.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface summarycellview : UIView
@property(nonatomic,strong)NSDictionary *suminfo;
@end
