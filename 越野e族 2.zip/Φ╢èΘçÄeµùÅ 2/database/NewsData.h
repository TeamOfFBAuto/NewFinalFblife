//
//  NewsData.h
//  FbLife
//
//  Created by 史忠坤 on 13-5-15.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsData : NSObject
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *bigimage;
@property(nonatomic,strong)NSString *bigimageid;
@property(nonatomic,strong)NSString *photo;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *publishtime;
@property(nonatomic,strong)NSString *summary;
@property(nonatomic,strong)NSString *id;

@end
