//
//  FaceScrollView.h
//  FaceDemo
//
//  Created by user on 11-10-20.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//


@interface FaceScrollView : UIScrollView

- (id)initWithFrame:(CGRect)rect target:(id)target;
/**
 *  这个好用
 */
@end
