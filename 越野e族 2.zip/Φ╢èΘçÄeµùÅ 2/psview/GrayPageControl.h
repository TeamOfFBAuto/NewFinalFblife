//
//  GrayPageControl.h
//  FbLife
//
//  Created by 史忠坤 on 13-5-3.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GrayPageControl : UIPageControl{
    UIImage* activeImage;
    UIImage* inactiveImage;
}

@end
